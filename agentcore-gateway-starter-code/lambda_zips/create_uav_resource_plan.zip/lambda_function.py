import json
import uuid
from typing import Dict, List, Any, Optional

# Global storage (in production, use DynamoDB/RDS)
active_plans = {}
slice_registry = {}
optimization_jobs = {}
handover_policies = {}
energy_profiles = {}
interference_maps = {}

# Helper functions that tools depend on
def deploy_a1_policy(policy_type: str, s_nssai: str, policy_params: Dict[str, Any]):
    policy_id = f"policy-{uuid.uuid4().hex[:8]}"
    print(f"A1: Deployed policy {policy_id} for slice {s_nssai}")
    return {"policyId": policy_id, "status": "DEPLOYED"}

def configure_e2_subscription(node_id: str, metrics: List[str], reporting_period: int):
    sub_id = f"e2sub-{uuid.uuid4().hex[:8]}"
    print(f"E2: Configured subscription {sub_id} for node {node_id}")
    return {"subscriptionId": sub_id, "status": "ACTIVE"}

def configure_slice_parameters(node_id: str, s_nssai: str, slice_config: Dict[str, Any]):
    config_id = f"o1cfg-{uuid.uuid4().hex[:8]}"
    print(f"O1: Applied slice config {config_id} to node {node_id}")
    return {"configId": config_id, "status": "APPLIED"}

def instantiate_vnf(vnf_type: str, flavor: str, slice_id: str):
    vnf_id = f"vnf-{uuid.uuid4().hex[:8]}"
    print(f"O2: Instantiated VNF {vnf_id} of type {vnf_type}")
    return {"vnfId": vnf_id, "status": "INSTANTIATED"}

# Main tool function
def create_uav_resource_plan(flight_path: List[Dict], uav_requirements: Dict[str, Any]):
    """Create flight path based UAV resource allocation plan"""
    plan_id = f"uav-{uuid.uuid4().hex[:8]}"
    plan = {
        "planId": plan_id,
        "type": "uav_resource_allocation",
        "flightPath": flight_path,
        "requirements": uav_requirements,
        "status": "CREATED"
    }
    print(f"Created UAV resource plan {plan_id}")
    return plan

def lambda_handler(event, context):
    """AWS Lambda entry point"""
    try:
        # Extract parameters directly from event
        flight_path = event.get('flight_path')
        uav_requirements = event.get('uav_requirements')
        
        # Call the tool function with parameters
        result = create_uav_resource_plan(flight_path, uav_requirements)
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(result, default=str)
        }
    except Exception as e:
        print(f"Error in create_uav_resource_plan: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e), 'tool': 'create_uav_resource_plan'})
        }
